# Blacksun.Xamarin
Repo for my Xamarin forms plugins, basing them on James montemagno's plugins projects structure so I can later submit them

For now support only for Bluetooth and UWP
