copy "Wire" to
C:\Program Files (x86)\Arduino\hardware\arduino\avr\libraries\