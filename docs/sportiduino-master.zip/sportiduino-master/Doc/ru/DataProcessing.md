### SportiduinoPQ

Настройка чипов и станций производится в программе [SportiduinoPQ](https://github.com/alexandervolikov/SportiduinoPQ)

Программа основана на [модуле на python](https://github.com/alexandervolikov/sportiduinoPython) а также на пакете PyQt для создания оконных приложений

Программа может выдавать распечатки, сохранять сырые данные в формате JSON для дальнейшей их обработки.

### SportOrg

Чтение чипов реализовано в программе [SportOrg ](https://github.com/sportorg/pysport)

[Сайт с руководством](http://sportorg.o-ural.ru/)